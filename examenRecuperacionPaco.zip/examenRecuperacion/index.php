<?php
require_once("db.php");
require_once("controllers/mainController.php");
?>


